﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

public class DialogueParser : MonoBehaviour {
    
	List<DialogueLine> lines ;

	struct DialogueLine
	{
		string name ;
		string content ;
        int pose;
		public DialogueLine (string n , string c , int p)
		{
			name = n ;
			content = c;
			pose = p; 
		}
	}

	// Use this for initialization
	void Start () {
    string file  = "Dialogue" ;
	string scenenum = EditorApplication.currentScene;
	scenenum = Regex.Replace(scenenum,"[^ 0  - 9]" , "") ;
    file += scenenum;
    file += ".txt";
	LoadDialogue(file);
	} 
	
	// Update is called once per frame
	void Update () {
		
	}

	void LoadDialogue (string filename) 
	{
       string file = "Assests/Resources/" + filename
	}
}
